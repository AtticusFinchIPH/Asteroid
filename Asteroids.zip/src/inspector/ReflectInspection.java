package inspector;

public class ReflectInspection {

  public static <S> Inspection fromObject(String name, S child) {
    return null;
  }
}
